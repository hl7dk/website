# Home - Danish Hackathon 2026 v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.dk/fhir/hackathons/ImplementationGuide/hl7.fhir.dk.hackathons | *Version*:1.0.0 |
| Active as of 2026-06-23 | *Computable Name*:DKHackathons |

# Danish Hackathon 2026

Welcome to the Danish Hackathon 2026 (Dk-hackathon) - a health data hackathon organized by [HL7 Denmark](https://hl7.dk/), held at the **Forskerparken 10 (at MedCom)** in **Odense, Denmark** on **October 6, 2026**.

The Dk-hackathon is held the day before the Danish e-health conference [eSundhedsobservatoriet](https://2026.e-sundhedsobservatoriet.dk/).

This hackathon is part of the [Nordic Health Data Hackathons](https://fhir.fi/hackathon/) series.

### Tracks

The hackathon includes three tracks:

1. **[Agentic Patient Access](track-agentic-patient-access.md)**- Led by Jens Villadsen
1. **[Telemedicin (beginners)](track-telemedicine.md)**- Led by Kirstine Rosenbeck
1. **[To be announced](track-3.md)**- Led by …

### Schedule

| | |
| :--- | :--- |
| 9:00 - 9:30 | Welcome and track introductions |
| 9:30 - 12:00 | Hacking |
| 12:00 - 13:00 | Working lunch (hacking continues) |
| 13:00 - 15:00 | Hacking |
| 15:30 - 16:30 | Track presentations and wrap-up |

### Preparation

Two preparatory meetings were held before the hackathon:

* **Webinar 1 - September 22, 9-10am**: General introduction, track overview, and homework.
* **Webinar 2 - Septemer 29, 1 hour for each track from 9-12am**: Track session intro, Q&A and homework

Each session will be recorded.

See the [Preparation](preparation.md) page for details.

### Results

See the [Results](results.md) page for details after the hackathon.

HL7 Denmark has a pitch session at eSundhedsobservatoriet on October 7. The results and experiences from the hackathon will be presented there. Participation from one of the hackers would be highly appreciated.

### Useful Links

* [HL7 Denmark](https://hl7.dk/)
* [HL7 FHIR R4](https://hl7.org/fhir/R4/)
* [FHIR Shorthand (FSH)](https://hl7.org/fhir/uv/shorthand/)
* [The Nordic FHIR terminology server](https://tx-nordics.fhir.org/fhir)

### Feedback & Support

If you have questions, feedback, or run into issues, please reach out:

* [Discussion on FHIR Zulip](??) - #nordics channel
* PRs to this IG are welcome at [hl7dk/dk-hackathons](https://github.com/hl7dk/dk-hackathons)

