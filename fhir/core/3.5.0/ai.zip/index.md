# Home - HL7 FHIR Implementation Guide: DK Core v3.5.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.dk/fhir/core/ImplementationGuide/hl7.fhir.dk.core | *Version*:3.5.0 |
| Active as of 2025-12-19 | *Computable Name*:DKCore |

### Introduction

This implementation guide is provided to support the use of FHIR®© in a Danish context.

This document is a working specification that is expected to be implemented and tested by FHIR®© system producers to enable feedback to improve the content of this guide. With this first Standard for Trial Use ballot version we are looking for feedback if the following goals are met:

* provide guidance on core resources for identifiers, code system, value sets and naming systems in a Danish specific context.
* define extensions that are necessary for local use covering needed Danish concepts

**Note**: This implementation guide is not (yet) a FHIR API specification, this will be a goal for the next iteration.

For more information about the Danish HL7 affiliate (HL7-Denmark), please go to [hl7.dk](https://www.hl7.dk). Here can you also find procurement recommendation in regards to FHIR, and an overview of some FHIR implementations in Denmark.

### Scope

The target group of this specification is any party that wants to specify FHIR standards for use in the Danish Health Sector. As a core-specification, a party that wants to use the specification should inherit from dk-core and build use-case specific profiles on top. As such, dk-core does not provide profiles for specific use use cases out-of-the-box.

This document presents Danish use concepts defined via FHIR processable artifacts:

* [Profiles](profiles.md) - are useful constraints of core FHIR resources and datatype for Danish use
* [Extensions](extensions.md) - are FHIR extensions that are added for local use, covering needed Danish concepts
* [Terminologies](terminology.md) - are defined or referenced code systems and value sets for Danish context

dk-core is regularly approved by HL7 Denmark and added to the [catalogue of approved standards](https://sundhedsdatastyrelsen.dk/digitale-loesninger/referencearkitektur-og-standarder/standardkatalog) governed by The Danish Health Data Authority, after consideration by RUSA (Rådgivende Udvalg for Standarder og Arkitektur). See the exact approvals for each version in the history page.

### Governance

FHIR profiles are managed under HL7 Denmark in the HL7 Danish FHIR working group:

* [Source](https://github.com/hl7dk/dk-core)
* [Wiki](https://github.com/hl7dk/dk-core)

### Collaboration

This guide is the product of collaborative work undertaken with participants from:

* [Danish FHIR Implementers Community](https://confluence.hl7.org/display/HD/DK+FHIR+SIG)
* [HL7 Denmark](https://www.hl7.dk)

#### Open an Issue in GitHub

The source code of this implementation guide is maintained in a [publicly accessible repository](https://github.com/hl7dk/dk-core) in GitHub. Issues opened in that GitHub repo are very welcome. They help the affiliate pick up any proposed changes or additions and to discuss them publicly.

#### Open a Pull Request in GitHub

Pull requests are even better. If you are in a position to suggest how exactly your proposal should be implemented in the specification, do it! It helps the team maintaining the implementation guide a great deal.

### Language

The main language of this implementation guide, and the profiles in it, is English. Content that does not have an official English term uses a Danish term instead. Sometimes terms are explained using both Danish and English. Danish terms and explanations are prefixed with [DA]

### Connection between dk-core and common Danish architectures and standards

HL7 Denmark includes common Danish architectures and standards if relevant, when content is added to dk-core. This section provides information about principle decisions as well as more specific ones that require explanations.

#### Principle decisions

* HL7 Denmark considers Danish legislation as the first source of truth when designing models, HL7 Denmark seeks to represent known named entities relevant for health data interoperability truthfully.
* HL7 Denmark upholds the requirements of the FHIR standard whenever it is possible within the boundaries of the Danish legislation.
* Entities that are named both in the FHIR standard and Danish legislation, keeps FHIR naming and requirements, but should explain its relation to Danish names/requirements.
* Danish standards and architectures are considered when designing FHIR profiles. HL7 Denmark uses them when they are relevant for interoperability of health data, and when they are compatible with the FHIR standard. Often public information and data models used as basis of public registries are too detailed, to warrant replication in a FHIR standard. E.g. The Organization profile references organization registries such as SOR and FK-ORG rather than re-constructing each of their attributes in the FHIR-profile, only attributes relevant for interoperability is provided in the FHIR profiles.

#### Specific decisions

* Patient.maritalStatus uses the extendable ValueSet required by the FHIR standard. However, Danish legislation and registries have two additional statuses not covered by the international ValueSet, so these two codes are added in dk-core.
* Several basic resources such as Patient and Organization has an address. In dk-core these addresses use the [FHIR datatype](http://hl7.org/fhir/R4/datatypes.html#Address), which is very basic compared to the [Danish Address standard](https://arkitektur.digst.dk/adresse). However, addresses can be referred faithfully using the international standard e.g. Address.text can be mapped directly to the Danish 'adressebetegnelse'. If more details are needed than FHIR instances provide, the [Danish address registry](https://danmarksadresser.dk/om-adresser/danmarks-adresseregister-dar) can be used for look-up.

### International Aspects

This implementation guide is refining the FHIR standard itself as well as using and depending on the FHIR Standard [International Patient Access (IPA) specification](https://hl7.org/fhir/uv/ipa/). IPA aims "to help patients access their data through patient-facing applications". While this is not the only scope of this implementation guide - it is part of the goal. IPA outlines a few minimum expectations that are required when exchanging data with patient facing apps.

Our main intent is to focus and limit profiling specific to Denmark. During the process, we actively monitor other national (base) profiles. We attempt to harmonize our base profiles with already published base profiles from other Nordic countries:

* [The Norwegian core profiles](https://simplifier.net/HL7Norwayno-basis/)
* [The Swedish Base Profiles](https://hl7.se/fhir/ig/base/)
* [The Finnish Base Profiles](https://hl7.fi/fhir/finnish-base-profiles/)

The implementation guide defines IPA compliance bit differently than the corresponding Nordic implementation guides where profiles extend the IPA profiles. DkCore instead introduces separate IPA DK versions of selected profiles that extend the dk-core profile and imposes the IPA equivalent. This makes it possible to choose whether to comply with the Danish requirements only, or to comply with both the Danish profiles and the IPA equivalents. It is recommended to comply with the IPA DK profiles where possible and with the non-IPA versions for contexts where IPA does not apply.

The requirements added in the IPA profiles are very limited and they will fit most use cases. The main constraints to be aware of are the requirements to patient identifiers, where IPA Patient has additional constraints on identifier and name that might not be relevant in message based exchange of information and may not fit legal requirements in reporting to clinical databases. Similarly, IPA Practitioner is required to have a name, which also can conflict in reporting scenarios.

Regarding international cooperation, please see also the [National IG Implementations](https://confluence.hl7.org/display/IC/National+IG+Implementations) page in HL7 International's Confluence.

### Safety Considerations

This implementation guide defines data elements, resources, formats, and methods for exchanging healthcare data between different participants in the healthcare process. As such, clinical safety is a key concern. Additional guidance regarding safety for the specification’s many and various implementations is available at: [https://www.hl7.org/FHIR/safety.html](https://www.hl7.org/FHIR/safety.html).

Although the present specification does gives users the opportunity to observe data protection and data security regulations, its use does not guarantee compliance with these regulations. Effective compliance must be ensured by appropriate measures during implementation projects and in daily operations. The corresponding implementation measures are explained in the standard. In addition, the present specification can only influence compliance with the security regulations in the technical area of standardization. It cannot influence organizational and contractual matters.

### License and Legal Terms

This document is licensed under Creative Commons "No Rights Reserved" ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).

HL7®, HEALTH LEVEL SEVEN®, FHIR® and the FHIR ![](icon-fhir-16.png)® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This implementation guide contains and references intellectual property owned by third parties ("Third Party IP"). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

See also http://hl7.org/fhir/license.html

Following is a non-exhaustive list of third-party artifacts and terminologies that may require a separate license:

**SNOMED Clinical Terms® (SNOMED CT®)** This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International (former known as International Health Terminology Standards Development Organisation IHTSDO). All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. “SNOMED” and “SNOMED CT” are registered trademarks of SNOMED International.

**Logical Observation Identifiers Names and Codes LOINC** This material contains content from LOINC® (http://loinc.org). The LOINC table, LOINC codes, and LOINC panels and forms file are copyright © 1995-2013, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and available at no cost under the license at http://loinc.org/terms-of-use.

### IP Statements

This publication includes IP covered under the following statements.

* [https://cms.npu-terminology.org/wp-content/uploads/2024/06/NPU-License-Terms-of-Use.pdf](https://cms.npu-terminology.org/wp-content/uploads/2024/06/NPU-License-Terms-of-Use.pdf)

* [Nomenclature for Properties and Units (NPU) - Fragment for DK Core](CodeSystem-dk-npu-fragment.md): [Bundle/ContinuaBundleWithDevice](Bundle-ContinuaBundleWithDevice.md), [DkCoreBasicObservation](StructureDefinition-dk-core-basic-observation.md)...Show 5 more,[NPUBasicObservation](ValueSet-dk-core-NPUBasicObservation.md),[Observation/ElseUrinStix](Observation-ElseUrinStix.md),[Observation/HeartRate.Poul.1974654](Observation-HeartRate.Poul.1974654.md),[Observation/ObservationOxySatObservation](Observation-ObservationOxySatObservation.md)and[Observation/Weight.Poul.230221](Observation-Weight.Poul.230221.md)


* IEEE maintains copyright on all content from IEEE 11073 standards. All rights reserved. Implementers should obtain official copies of all applicable standards documents directly from IEEE. The inclusion of IEEE 11073 terminology codes and definitions in HL7 messages and related implementation guides is permitted under existing agreements. For permission regarding any other usage, please contact IEEE at copyrights@ieee.org.

* [ISO/IEEE 11073 Medical Device Communication Nomenclature](http://terminology.hl7.org/6.5.0/CodeSystem-v3-mdc.html): [Bundle/ContinuaBundleWithDevice](Bundle-ContinuaBundleWithDevice.md), [Device/BPMonitor.C4F312FFFE53F2C9](Device-BPMonitor.C4F312FFFE53F2C9.md)...Show 9 more,[Device/Telma.FEEDDADADEADBEEF](Device-Telma.FEEDDADADEADBEEF.md),[Device/WeightScale.606405FFFECFC604](Device-WeightScale.606405FFFECFC604.md),[DkCoreBasicObservation](StructureDefinition-dk-core-basic-observation.md),[IEEEBasicObservation](ValueSet-dk-core-IEEEBasicObservation.md),[Observation/CoincidentTimeStamp.0222](Observation-CoincidentTimeStamp.0222.md),[Observation/HeartRate.Poul.1974654](Observation-HeartRate.Poul.1974654.md),[Observation/ObservationOxySatBasicObservationOrg](Observation-ObservationOxySatBasicObservationOrg.md),[Observation/ObservationOxySatObservation](Observation-ObservationOxySatObservation.md)and[Observation/Weight.Poul.230221](Observation-Weight.Poul.230221.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [AddressType](CodeSystem-address-type-dk-supplement.md), [AddressUse](CodeSystem-address-use-dk-supplement.md)...Show 71 more,[AdministrativeGenderDkSupplement](CodeSystem-administrative-gender-supplement.md),[AuthorizationIdentifier](StructureDefinition-dk-core-authorization-identifier.md),[CVRIdentifier](StructureDefinition-dk-core-cvr-identifier.md),[CareProvider](StructureDefinition-dk-core-care-provider.md),[CareTeamStatus](CodeSystem-care-team-status-dk-supplement.md),[ConditionLastAssertedDate](StructureDefinition-ConditionLastAssertedDate.md),[ConsentState](CodeSystem-consent-state-codes-dk-supplement.md),[DK Central Healthcare Organization Registry (SOR)](NamingSystem-sor.md),[DK Central Person Registry (CPR)](NamingSystem-cpr.md),[DKCore](index.md),[DKCoreRegionalSubdivisionCodes](CodeSystem-dk-core-regional-subdivision-codes.md),[DaysOfWeek](CodeSystem-days-of-week-dk-supplement.md),[DkCoreBasicObservation](StructureDefinition-dk-core-basic-observation.md),[DkCoreCondition](StructureDefinition-dk-core-condition.md),[DkCoreCprIdentifier](StructureDefinition-dk-core-cpr-identifier.md),[DkCoreDeCPRCodes](CodeSystem-dk-core-d-ecpr-codes.md),[DkCoreDeCPRValueSet](ValueSet-DkCoreDeCPRValueSet.md),[DkCoreDeCprIdentifier](StructureDefinition-dk-core-d-ecpr-identifier.md),[DkCoreDocumentReferenceVersionID](StructureDefinition-dk-core-documentreference-version-id-extension.md),[DkCoreEncounter](StructureDefinition-dk-core-encounter.md),[DkCoreEncounterPriority](ValueSet-dk-core-encounter-priority.md),[DkCoreLocation](StructureDefinition-dk-core-location.md),[DkCoreMinimalDocumentReference](StructureDefinition-dk-core-minimaldocumentreference.md),[DkCoreObservation](StructureDefinition-dk-core-observation.md),[DkCoreOrganization](StructureDefinition-dk-core-organization.md),[DkCorePatient](StructureDefinition-dk-core-patient.md),[DkCorePersonServiceRequest](StructureDefinition-dk-core-person-servicerequest.md),[DkCorePractitioner](StructureDefinition-dk-core-practitioner.md),[DkCorePractitionerRole](StructureDefinition-dk-core-practitioner-role.md),[DkCorePriorityCodes](ValueSet-dk-core-priority-codes.md),[DkCoreProfessionGroupCodes](CodeSystem-DkCoreProfessionGroupCodes.md),[DkCoreProfessionGroupValueSet](ValueSet-DkCoreProfessionGroupValueSet.md),[DkCoreRelatedPerson](StructureDefinition-dk-core-related-person.md),[DkCoreServiceRequestCodes](ValueSet-dk-core-servicerequest-codes.md),[DkCoreXeCprIdentifier](StructureDefinition-dk-core-x-ecpr-identifier.md),[DkMaritalStatus](CodeSystem-dk-marital-status.md),[DkRelatedPersonRelationshipCodes](CodeSystem-dk-relatedperson-relationshipcodes.md),[EpisodeOfCareStatus](CodeSystem-episode-of-care-status-dk-supplement.md),[GLNIdentifier](StructureDefinition-dk-core-gln-identifier.md),[GreenlandMunicipalityCodes](CodeSystem-dk-core-municipality-codes-greenland.md),[IEEEBasicObservation](ValueSet-dk-core-IEEEBasicObservation.md),[IpaDkCoreCondition](StructureDefinition-ipa-dk-core-condition.md),[IpaDkCoreObservation](StructureDefinition-ipa-dk-core-observation.md),[IpaDkCorePatient](StructureDefinition-ipa-dk-core-patient.md),[IpaDkCorePractitioner](StructureDefinition-ipa-dk-core-practitioner.md),[IpaDkCorePractitionerRole](StructureDefinition-ipa-dk-core-practitionerrole.md),[KombitOrgIdentifier](StructureDefinition-dk-core-kombit-org-identifier.md),[LoincBasicObservation](ValueSet-dk-core-LoincBasicObservation.md),[MunicipalityCodes](ValueSet-dk-core-MunicipalityCodes.md),[NPU](CodeSystem-dk-npu-fragment.md),[NPUBasicObservation](ValueSet-dk-core-NPUBasicObservation.md),[NotFollowedAnymore](StructureDefinition-NotFollowedAnymore.md),[Patient/283](Patient-283.md),[PlannedEndDate](StructureDefinition-dk-core-planned-end-date.md),[PlannedStartDate](StructureDefinition-dk-core-planned-start-date.md),[ProducentId](StructureDefinition-dk-core-producent-id.md),[PublicationStatus](CodeSystem-publication-status-dk-supplement.md),[RegionalSubDivisionCodes](StructureDefinition-dk-core-RegionalSubDivisionCodes.md),[RegionalSubdivisionCodes](ValueSet-dk-core-RegionalSubDivisionCodes.md),[RelatedPersonRelationshipTypes](ValueSet-dk-core-RelatedPersonRelationshipTypes.md),[RequestStatus](CodeSystem-request-status-dk-supplement.md),[RoleCodeDkSupplement](CodeSystem-role-code-dk-supplement.md),[SCTBasicObservation](ValueSet-dk-core-SCTBasicObservation.md),[SORIdentifier](StructureDefinition-dk-core-sor-identifier.md),[SorOrganizationType](ValueSet-sor-organization-type.md),[SorPracticeSettingCode](ValueSet-dk-core-practice-setting-code.md),[TechniquesSCTCodes](ValueSet-dk-core-TechniquesSCTCodes.md),[UCUMBasicUnits](ValueSet-dk-core-UCUM-BasicUnits.md),[ValueSet/dk-marital-status](ValueSet-dk-marital-status.md),[extended-patient-contactrelationship](ValueSet-extended-patient-contactrelationship.md)and[v2-0131DkSupplement](CodeSystem-v2-0131-supplement.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html): [Bundle/ContinuaBundleWithDevice](Bundle-ContinuaBundleWithDevice.md), [Bundle/ElsesTOBS](Bundle-ElsesTOBS.md)...Show 19 more,[Bundle/MaxTOKS](Bundle-MaxTOKS.md),[DkCoreBasicObservation](StructureDefinition-dk-core-basic-observation.md),[Observation/ElseBloodPressure](Observation-ElseBloodPressure.md),[Observation/ElseBodyTemperature](Observation-ElseBodyTemperature.md),[Observation/ElseHeartRate](Observation-ElseHeartRate.md),[Observation/ElseRespirationRate](Observation-ElseRespirationRate.md),[Observation/ElsesTOBSscore](Observation-ElsesTOBSscore.md),[Observation/HeartRate.Poul.1974654](Observation-HeartRate.Poul.1974654.md),[Observation/MaxBloodPressure](Observation-MaxBloodPressure.md),[Observation/MaxBodyTemperature](Observation-MaxBodyTemperature.md),[Observation/MaxGlasgowComaScale](Observation-MaxGlasgowComaScale.md),[Observation/MaxHeartRate](Observation-MaxHeartRate.md),[Observation/MaxRespirationRate](Observation-MaxRespirationRate.md),[Observation/MaxSaturation](Observation-MaxSaturation.md),[Observation/ObservationOxySatBasicObservationOrg](Observation-ObservationOxySatBasicObservationOrg.md),[Observation/ObservationOxySatObservation](Observation-ObservationOxySatObservation.md),[Observation/ObservationRespiratoryBasicObservation](Observation-ObservationRespiratoryBasicObservation.md),[Observation/Weight.Poul.230221](Observation-Weight.Poul.230221.md)and[UCUMBasicUnits](ValueSet-dk-core-UCUM-BasicUnits.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [Bundle/ContinuaBundleWithDevice](Bundle-ContinuaBundleWithDevice.md), [Bundle/ElsesTOBS](Bundle-ElsesTOBS.md)...Show 22 more,[Bundle/MaxTOKS](Bundle-MaxTOKS.md),[DkCoreBasicObservation](StructureDefinition-dk-core-basic-observation.md),[DocumentReference/94e65db8-2f0c-4a2c-a7c9-06a160d59a12](DocumentReference-94e65db8-2f0c-4a2c-a7c9-06a160d59a12.md),[DocumentReference/94e65db8-2f0c-4a2c-a7c9-06a160d59a13](DocumentReference-94e65db8-2f0c-4a2c-a7c9-06a160d59a13.md),[LoincBasicObservation](ValueSet-dk-core-LoincBasicObservation.md),[Observation/ElseBloodPressure](Observation-ElseBloodPressure.md),[Observation/ElseBodyTemperature](Observation-ElseBodyTemperature.md),[Observation/ElseHeartRate](Observation-ElseHeartRate.md),[Observation/ElseRespirationRate](Observation-ElseRespirationRate.md),[Observation/HeartRate.Poul.1974654](Observation-HeartRate.Poul.1974654.md),[Observation/MaxBloodPressure](Observation-MaxBloodPressure.md),[Observation/MaxBodyTemperature](Observation-MaxBodyTemperature.md),[Observation/MaxConsciousness](Observation-MaxConsciousness.md),[Observation/MaxGlasgowComaScale](Observation-MaxGlasgowComaScale.md),[Observation/MaxHeartRate](Observation-MaxHeartRate.md),[Observation/MaxRespirationRate](Observation-MaxRespirationRate.md),[Observation/MaxSaturation](Observation-MaxSaturation.md),[Observation/MaxVitalSignsPanel](Observation-MaxVitalSignsPanel.md),[Observation/ObservationOxySatBasicObservationOrg](Observation-ObservationOxySatBasicObservationOrg.md),[Observation/ObservationOxySatObservation](Observation-ObservationOxySatObservation.md),[Observation/ObservationRespiratoryBasicObservation](Observation-ObservationRespiratoryBasicObservation.md)and[Observation/Weight.Poul.230221](Observation-Weight.Poul.230221.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://tx.fhir.org/r4/ValueSet/snomedct): [AddressType](CodeSystem-address-type-dk-supplement.md), [AddressUse](CodeSystem-address-use-dk-supplement.md)...Show 49 more,[Bundle/ElsesTOBS](Bundle-ElsesTOBS.md),[Bundle/MaxTOKS](Bundle-MaxTOKS.md),[CareTeamStatus](CodeSystem-care-team-status-dk-supplement.md),[Condition/ConditionPressureUlcer](Condition-ConditionPressureUlcer.md),[Condition/JohnPacemaker](Condition-JohnPacemaker.md),[ConsentState](CodeSystem-consent-state-codes-dk-supplement.md),[DaysOfWeek](CodeSystem-days-of-week-dk-supplement.md),[DkCoreBasicObservation](StructureDefinition-dk-core-basic-observation.md),[DkCoreCondition](StructureDefinition-dk-core-condition.md),[DkCoreMinimalDocumentReference](StructureDefinition-dk-core-minimaldocumentreference.md),[DkCoreObservation](StructureDefinition-dk-core-observation.md),[DkCoreOrganization](StructureDefinition-dk-core-organization.md),[DkCorePersonServiceRequest](StructureDefinition-dk-core-person-servicerequest.md),[DkCoreServiceRequestCodes](ValueSet-dk-core-servicerequest-codes.md),[DocumentReference/94e65db8-2f0c-4a2c-a7c9-06a160d59a12](DocumentReference-94e65db8-2f0c-4a2c-a7c9-06a160d59a12.md),[DocumentReference/94e65db8-2f0c-4a2c-a7c9-06a160d59a13](DocumentReference-94e65db8-2f0c-4a2c-a7c9-06a160d59a13.md),[EpisodeOfCareStatus](CodeSystem-episode-of-care-status-dk-supplement.md),[IEEEBasicObservation](ValueSet-dk-core-IEEEBasicObservation.md),[Lægerne Hasseris Bymidte](Organization-LaegerneHasserisBymidte.md),[Observation/ElseBloodPressure](Observation-ElseBloodPressure.md),[Observation/ElseBodyTemperature](Observation-ElseBodyTemperature.md),[Observation/ElseConsciousness](Observation-ElseConsciousness.md),[Observation/ElseHeartRate](Observation-ElseHeartRate.md),[Observation/ElsePainVRS](Observation-ElsePainVRS.md),[Observation/ElseRespirationRate](Observation-ElseRespirationRate.md),[Observation/ElseUrinStix](Observation-ElseUrinStix.md),[Observation/MaxBloodPressure](Observation-MaxBloodPressure.md),[Observation/MaxBodyTemperature](Observation-MaxBodyTemperature.md),[Observation/MaxConsciousness](Observation-MaxConsciousness.md),[Observation/MaxGlasgowComaScale](Observation-MaxGlasgowComaScale.md),[Observation/MaxHeartRate](Observation-MaxHeartRate.md),[Observation/MaxRespirationRate](Observation-MaxRespirationRate.md),[Observation/MaxSaturation](Observation-MaxSaturation.md),[Organization/154b8c96-a061-45bf-9ce4-1947c7c3c283](Organization-154b8c96-a061-45bf-9ce4-1947c7c3c283.md),[Organization/CenterForDiabetes](Organization-CenterForDiabetes.md),[Organization/CenterForDiabetesTeamDiabetes](Organization-CenterForDiabetesTeamDiabetes.md),[Organization/CenterForDiabetesTeamHjerte](Organization-CenterForDiabetesTeamHjerte.md),[Organization/CenterForDiabetesTeamKvalitet](Organization-CenterForDiabetesTeamKvalitet.md),[Organization/b08997bb-4476-4dd0-84dd-2e297f809364](Organization-b08997bb-4476-4dd0-84dd-2e297f809364.md),[Ortopædkirurgisk sengeafdeling](Organization-8510eec9-180b-4e9c-95b6-02fad9f853d3.md),[Ortopædkirurgisk sengeafsnit](Organization-19f9ee18-7677-4caf-88fe-8f6df2f2906e.md),[PublicationStatus](CodeSystem-publication-status-dk-supplement.md),[RequestStatus](CodeSystem-request-status-dk-supplement.md),[SCTBasicObservation](ValueSet-dk-core-SCTBasicObservation.md),[ServiceRequest/JohnsServiceRequest](ServiceRequest-JohnsServiceRequest.md),[ServiceRequest/MaxServiceRequest](ServiceRequest-MaxServiceRequest.md),[SorOrganizationType](ValueSet-sor-organization-type.md),[SorPracticeSettingCode](ValueSet-dk-core-practice-setting-code.md)and[TechniquesSCTCodes](ValueSet-dk-core-TechniquesSCTCodes.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Condition Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-category.html): [Condition/ConditionPressureUlcer](Condition-ConditionPressureUlcer.md), [Condition/ElseGraviditet](Condition-ElseGraviditet.md)...Show 4 more,[Condition/JohnDiabetes](Condition-JohnDiabetes.md),[Condition/JohnFracture](Condition-JohnFracture.md),[Condition/JohnMelanoma](Condition-JohnMelanoma.md)and[Condition/JohnPacemaker](Condition-JohnPacemaker.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-condition-clinical.html): [Condition/ConditionPressureUlcer](Condition-ConditionPressureUlcer.md), [Condition/ElseGraviditet](Condition-ElseGraviditet.md)...Show 4 more,[Condition/JohnDiabetes](Condition-JohnDiabetes.md),[Condition/JohnFracture](Condition-JohnFracture.md),[Condition/JohnMelanoma](Condition-JohnMelanoma.md)and[Condition/JohnPacemaker](Condition-JohnPacemaker.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.0.1/CodeSystem-condition-ver-status.html): [Condition/ElseGraviditet](Condition-ElseGraviditet.md), [Condition/JohnDiabetes](Condition-JohnDiabetes.md), [Condition/JohnFracture](Condition-JohnFracture.md), [Condition/JohnMelanoma](Condition-JohnMelanoma.md) and [Condition/JohnPacemaker](Condition-JohnPacemaker.md)
* [Location type](http://terminology.hl7.org/7.0.1/CodeSystem-location-physical-type.html): [Location/ambulance](Location-ambulance.md) and [Neuro unit](Location-neuroradiologyUnit.md)
* [Observation Category Codes](http://terminology.hl7.org/7.0.1/CodeSystem-observation-category.html): [Bundle/ContinuaBundleWithDevice](Bundle-ContinuaBundleWithDevice.md), [Bundle/ElsesTOBS](Bundle-ElsesTOBS.md)...Show 18 more,[Bundle/MaxTOKS](Bundle-MaxTOKS.md),[DkCoreBasicObservation](StructureDefinition-dk-core-basic-observation.md),[Observation/ElseBloodPressure](Observation-ElseBloodPressure.md),[Observation/ElseBodyTemperature](Observation-ElseBodyTemperature.md),[Observation/ElseHeartRate](Observation-ElseHeartRate.md),[Observation/ElseRespirationRate](Observation-ElseRespirationRate.md),[Observation/HeartRate.Poul.1974654](Observation-HeartRate.Poul.1974654.md),[Observation/MaxBloodPressure](Observation-MaxBloodPressure.md),[Observation/MaxBodyTemperature](Observation-MaxBodyTemperature.md),[Observation/MaxConsciousness](Observation-MaxConsciousness.md),[Observation/MaxHeartRate](Observation-MaxHeartRate.md),[Observation/MaxRespirationRate](Observation-MaxRespirationRate.md),[Observation/MaxSaturation](Observation-MaxSaturation.md),[Observation/MaxVitalSignsPanel](Observation-MaxVitalSignsPanel.md),[Observation/ObservationOxySatBasicObservationOrg](Observation-ObservationOxySatBasicObservationOrg.md),[Observation/ObservationOxySatObservation](Observation-ObservationOxySatObservation.md),[Observation/ObservationRespiratoryBasicObservation](Observation-ObservationRespiratoryBasicObservation.md)and[Observation/Weight.Poul.230221](Observation-Weight.Poul.230221.md)
* [contactRole2](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0131.html): [v2-0131DkSupplement](CodeSystem-v2-0131-supplement.md)
* [identifierType](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0203.html): [Bundle/ContinuaBundleWithDevice](Bundle-ContinuaBundleWithDevice.md), [DK Central Healthcare Organization Registry (SOR)](NamingSystem-sor.md) and [Patient/Poul](Patient-Poul.md)
* [providerRole](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0286.html): [PractitionerRole/AbrahamPractitionerRole](PractitionerRole-AbrahamPractitionerRole.md) and [PractitionerRole/PlaceholderPractitionerRole](PractitionerRole-PlaceholderPractitionerRole.md)
* [ActCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html): [DkCoreMinimalDocumentReference](StructureDefinition-dk-core-minimaldocumentreference.md), [Encounter/0c5e4905-5c2e-4254-8837-770c3724cd13](Encounter-0c5e4905-5c2e-4254-8837-770c3724cd13.md) and [Encounter/915a3cfb-2f3e-477b-8a9d-5d86c30e4929](Encounter-915a3cfb-2f3e-477b-8a9d-5d86c30e4929.md)
* [ActPriority](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActPriority.html): [DkCoreEncounter](StructureDefinition-dk-core-encounter.md) and [DkCoreEncounterPriority](ValueSet-dk-core-encounter-priority.md)
* [MaritalStatus](http://terminology.hl7.org/7.0.1/CodeSystem-v3-MaritalStatus.html): [Bundle/ElsesTOBS](Bundle-ElsesTOBS.md), [Patient/283](Patient-283.md) and [Patient/else](Patient-else.md)
* [RoleCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-RoleCode.html): [DkCoreRelatedPerson](StructureDefinition-dk-core-related-person.md), [Location/ambulance](Location-ambulance.md)...Show 5 more,[Neuro unit](Location-neuroradiologyUnit.md),[RelatedPerson/Child](RelatedPerson-Child.md),[RelatedPerson/TwoRelations](RelatedPerson-TwoRelations.md),[RelatedPersonRelationshipTypes](ValueSet-dk-core-RelatedPersonRelationshipTypes.md)and[RoleCodeDkSupplement](CodeSystem-role-code-dk-supplement.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.dk.core.r4)](package.r4.tgz) and [R4B (hl7.fhir.dk.core.r4b)](package.r4b.tgz) are available.

### Dependency Table










### Globals Table

*There are no Global profiles defined*

