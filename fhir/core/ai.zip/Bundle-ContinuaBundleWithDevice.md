# Poul's home blood pressure measurement - HL7 FHIR Implementation Guide: DK Core v3.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Poul's home blood pressure measurement**

## Example Bundle: Poul's home blood pressure measurement

The following example shows a real-life recording of a home monitoring blood pressure measurement. Due to the size and complexity of this example, a bit of background and guidance on the contents will be provided

## Background

In many situations citizens may use personal equipment (their own property or borrowed from a healthcare provider) to automatically capture and record medical observations. This class of equipment is known by the term "Personal Health Devices" (PHDs). A number of challenges arise from the complexity of dealing with diverse consumer-grade Internet-connected equipment used under no clinical supervision:

* Type, quality, accuracy and provenance of the observations?
* Systematically recording the state of sensors and relevant events detected during the measurement.
* Meta information regarding the equipment, the observation, or the context.
* What is the identity of the patient/citizen/user? Authorization, authentication, etc…
* Accuracy of timestamps, consistency of timelines etc. In particular when the PHD is used by someone traveling around the globe.

### Standardization and Interoperability

In order to deal with these challenges and coordinate the effort across many different standardization bodies, the [Continua Design Guidelines (CDG)](https://www.pchalliance.org/continua-design-guidelines) has been created, and the coordination effort continues under the [IHE Personal Connected Health (PCH)](https://wiki.ihe.net/index.php/Personal_Connected_Health) program. In 2013, Denmark adopted the CDG as a [reference architecture](https://sundhedsdatastyrelsen.dk/-/media/sds/filer/rammer-og-retningslinjer/referenceaktitektur-og-it-standarder/referencearkitektur/referencearchitecture-collecting-health-data-citizens.pdf).

The CDG offers guidance to implementors of PHD equipment and related applications, providing a single data model that may be expressed and exchanged using (and translated back and forth between) many different container formats and transports:

* [IEEE 11073 PHD](http://11073.org/)
* [HL7 FHIR PHD IG](http://hl7.org/fhir/uv/phd/)
* [HL7 CDA PHMR](https://www.hl7.org/implement/standards/product_brief.cfm?product_id=33)
* [IHE PCD-01](https://wiki.ihe.net/index.php/PCD_Technical_Framework) using HL7 v2 Messaging
* [IHE POU](https://wiki.ihe.net/index.php/Personal_Health_Device_Observation_Upload)

With transports ranging from [Bluetooth Low Energy](https://www.bluetooth.com/bluetooth-resources/personal-health-devices-transcoding/), NFC, USB, ZigBee, Matter, Internet, to [XDS.b and XDR exchange of PHMR documents](https://www.itu.int/rec/dologin_pub.asp?lang=e&id=T-REC-H.813-201911-I!!PDF-E&type=items)

## Bundle Overview and Reader's Guide

The example provided here is the data payload transferred from the home of the user over the Internet to a central collection server at a tele-monitoring service provider. This bundle is a single self-contained message, demonstrating how a blood pressure measurement is encoded using a FHIR Bundle compliant to **both** the [HL7 FHIR PHD IG](http://hl7.org/fhir/uv/phd/) **and** the `DkCoreObservation` profiles.

### Bundle Structure and Content

The Bundle contains the following entries:

* **The Patient** As the bundle must be self-contained, a Patient resource must be included. This is of course a `DkCorePatient`.
* **The Gateway Device** The blood pressure monitor device used in this case is not aware of the identity of its user. It will just send the measurement using Bluetooth Low Energy to a compliant gateway. The gateway - in this case an Android app - is responsible for adding the identity of the patient, and also for checking (and correcting if necessary) the blood pressure monitor's built-in clock, which is used to create the observation timestamps.
* **The PHD** In this case, a blood pressure monitor from A&D was used to create a blood pressure measurement.
* **Battery Level Observation** The A&D blood pressure monitor gauges its own battery every time it is used.
* **Coincident Timestamp Observation** The Gateway Device reads the clock of the PHD and creates this observation of the **current time** of the PHD timestamped using the Gateway's clock (which is supposed to be synchronized with a time service). This is a way to detect (and possibly correct) breaches in the timeline.
* **Blood Pressure Observation** This is an `IPADkCoreObservation`
* **Heart Rate Observation** Also an `IPADkCoreObservation`
* **Blood Pressure Status Observation** This observation type can be used to report a number of conditions during the measurement. In this case, an irregular pulse was detected during the measurement. Some PHDs may be able to report different conditions - e.g. that the blood pressure cuff was too loose.

You may also notice that the type of the Bundle is a transaction bundle and that all the entries in the bundle are conditional creates using a funny-looking identifier, which is actually the result of a calculated function that summarises the resource into a short form (hash), in order to prevent duplicates.

## Narrative Content



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ContinuaBundleWithDevice",
  "type" : "transaction",
  "entry" : [
    {
      "fullUrl" : "http://hl7.dk/fhir/core/Patient/Poul",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "Poul",
        "meta" : {
          "profile" : [
            "http://hl7.dk/fhir/core/StructureDefinition/dk-core-patient",
            "http://hl7.org/fhir/uv/phd/StructureDefinition/PhdPatient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_Poul\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient Poul</b></p><a name=\"Poul\"> </a><a name=\"hcPoul\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-dk-core-patient.html\">Danish Core Patient Profile</a>, <a href=\"http://hl7.org/fhir/uv/phd/STU1.1/StructureDefinition-PhdPatient.html\">PhdPatient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</p><hr/></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "NI"
                }
              ]
            },
            "system" : "urn:oid:1.2.208.176.1.2",
            "value" : "3001749995"
          }
        ],
        "name" : [
          {
            "text" : "Poul Hansen",
            "family" : "Hansen",
            "given" : ["Poul"]
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Patient",
        "ifNoneExist" : "identifier=urn:oid:1.2.208.176.1.2|3001749995"
      }
    },
    {
      "fullUrl" : "http://hl7.dk/fhir/core/Device/Telma.FEEDDADADEADBEEF",
      "resource" : {
        "resourceType" : "Device",
        "id" : "Telma.FEEDDADADEADBEEF",
        "meta" : {
          "profile" : ["http://hl7.org/fhir/uv/phd/StructureDefinition/PhgDevice"]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_Telma.FEEDDADADEADBEEF\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device Telma.FEEDDADADEADBEEF</b></p><a name=\"Telma.FEEDDADADEADBEEF\"> </a><a name=\"hcTelma.FEEDDADADEADBEEF\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/phd/STU1.1/StructureDefinition-PhgDevice.html\">PhgDevice</a></p></div><p><b>identifier</b>: IEEE 11073 System Identifier/FE-ED-DA-DA-DE-AD-BE-EF</p><p><b>manufacturer</b>: Trifork</p><p><b>modelNumber</b>: Telma (Android)</p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 531981}\">MDC_MOC_VMS_MDS_AHD: Continua compliant gateway</span></p><blockquote><p><b>version</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 532352}\">MDC_REG_CERT_DATA_CONTINUA_VERSION: Continua version</span></p><p><b>value</b>: 7.0</p></blockquote><blockquote><p><b>version</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 531974}\">MDC_ID_PROD_SPEC_HW: Hardware version</span></p><p><b>value</b>: Samsung Tab S7+ (SM-T970)</p></blockquote><blockquote><p><b>version</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 531975}\">MDC_ID_PROD_SPEC_SW: Software version</span></p><p><b>value</b>: 1.2.0 (build 2662)</p></blockquote><blockquote><p><b>version</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 531976}\">MDC_ID_PROD_SPEC_FW: Firmware version</span></p><p><b>value</b>: Android 12 (API 31)</p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 532353}\">MDC_REG_CERT_DATA_CONTINUA_CERT_DEV_LIST: Continua certified device list</span></p><p><b>valueCode</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaPHD 32783}\">BluetoothLE: Weighing scale</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaPHD 32775}\">BluetoothLE: Blood pressure monitor</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaPHD 32772}\">BluetoothLE: Pulse oximeter</span></p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 532355}\">MDC_REG_CERT_DATA_CONTINUA_AHD_CERT_LIST: Continua certified Health&amp;Fitness interfaces list</span></p><p><b>valueCode</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaHFS 7}\">observation-upload-fhir: FHIR resource upload</span></p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 68220}\">MDC_TIME_SYNC_PROTOCOL: Time synchronization protocol</span></p><p><b>valueCode</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 532226}\">MDC_TIME_SYNC_NTPV4: NTPV4 time synchronization</span></p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7 532354.0}\">regulation-status</span></p><p><b>valueCode</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Device is NOT regulated</span></p></blockquote></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaDeviceIdentifiers",
                  "code" : "SYSID",
                  "display" : "IEEE 11073 System Identifier"
                }
              ]
            },
            "system" : "urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2680",
            "value" : "FE-ED-DA-DA-DE-AD-BE-EF"
          }
        ],
        "manufacturer" : "Trifork",
        "modelNumber" : "Telma (Android)",
        "type" : {
          "coding" : [
            {
              "system" : "urn:iso:std:iso:11073:10101",
              "code" : "531981",
              "display" : "MDC_MOC_VMS_MDS_AHD"
            }
          ],
          "text" : "MDC_MOC_VMS_MDS_AHD: Continua compliant gateway"
        },
        "version" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "532352",
                  "display" : "MDC_REG_CERT_DATA_CONTINUA_VERSION"
                }
              ],
              "text" : "MDC_REG_CERT_DATA_CONTINUA_VERSION: Continua version"
            },
            "value" : "7.0"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "531974",
                  "display" : "MDC_ID_PROD_SPEC_HW"
                }
              ],
              "text" : "MDC_ID_PROD_SPEC_HW: Hardware version"
            },
            "value" : "Samsung Tab S7+ (SM-T970)"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "531975",
                  "display" : "MDC_ID_PROD_SPEC_SW"
                }
              ],
              "text" : "MDC_ID_PROD_SPEC_SW: Software version"
            },
            "value" : "1.2.0 (build 2662)"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "531976",
                  "display" : "MDC_ID_PROD_SPEC_FW"
                }
              ],
              "text" : "MDC_ID_PROD_SPEC_FW: Firmware version"
            },
            "value" : "Android 12 (API 31)"
          }
        ],
        "property" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "532353",
                  "display" : "MDC_REG_CERT_DATA_CONTINUA_CERT_DEV_LIST"
                }
              ],
              "text" : "MDC_REG_CERT_DATA_CONTINUA_CERT_DEV_LIST: Continua certified device list"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaPHD",
                    "code" : "32783"
                  }
                ],
                "text" : "BluetoothLE: Weighing scale"
              },
              {
                "coding" : [
                  {
                    "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaPHD",
                    "code" : "32775"
                  }
                ],
                "text" : "BluetoothLE: Blood pressure monitor"
              },
              {
                "coding" : [
                  {
                    "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaPHD",
                    "code" : "32772"
                  }
                ],
                "text" : "BluetoothLE: Pulse oximeter"
              }
            ]
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "532355",
                  "display" : "MDC_REG_CERT_DATA_CONTINUA_AHD_CERT_LIST"
                }
              ],
              "text" : "MDC_REG_CERT_DATA_CONTINUA_AHD_CERT_LIST: Continua certified Health&Fitness interfaces list"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaHFS",
                    "code" : "7",
                    "display" : "observation-upload-fhir"
                  }
                ],
                "text" : "observation-upload-fhir: FHIR resource upload"
              }
            ]
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "68220",
                  "display" : "MDC_TIME_SYNC_PROTOCOL"
                }
              ],
              "text" : "MDC_TIME_SYNC_PROTOCOL: Time synchronization protocol"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "urn:iso:std:iso:11073:10101",
                    "code" : "532226",
                    "display" : "MDC_TIME_SYNC_NTPV4"
                  }
                ],
                "text" : "MDC_TIME_SYNC_NTPV4: NTPV4 time synchronization"
              }
            ]
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7",
                  "code" : "532354.0"
                }
              ],
              "text" : "regulation-status"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                    "code" : "Y"
                  }
                ],
                "text" : "Device is NOT regulated"
              }
            ]
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Device",
        "ifNoneExist" : "identifier=urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2680|FE-ED-DA-DA-DE-AD-BE-EF"
      }
    },
    {
      "fullUrl" : "http://hl7.dk/fhir/core/Device/BPMonitor.C4F312FFFE53F2C9",
      "resource" : {
        "resourceType" : "Device",
        "id" : "BPMonitor.C4F312FFFE53F2C9",
        "meta" : {
          "profile" : ["http://hl7.org/fhir/uv/phd/StructureDefinition/PhdDevice"]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_BPMonitor.C4F312FFFE53F2C9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device BPMonitor.C4F312FFFE53F2C9</b></p><a name=\"BPMonitor.C4F312FFFE53F2C9\"> </a><a name=\"hcBPMonitor.C4F312FFFE53F2C9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/phd/STU1.1/StructureDefinition-PhdDevice.html\">PhdDevice</a></p></div><p><b>identifier</b>: Ieee 11073 System Identifier/C4-F3-12-FF-FE-53-F2-C9, Bluetooth MAC address/C4-F3-12-53-F2-C9</p><p><b>manufacturer</b>: A&amp;D Medical </p><p><b>serialNumber</b>: 5181000124</p><p><b>modelNumber</b>: UA-651BLE </p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 65573}\">MDC_MOC_VMS_MDS_SIMP: Personal health device</span></p><h3>Specializations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>SystemType</b></td><td><b>Version</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:11073:10101 528391}\">MDC_DEV_SPEC_PROFILE_BP: Blood Pressure meter</span></td><td>1</td></tr></table><blockquote><p><b>version</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 532352}\">MDC_REG_CERT_DATA_CONTINUA_VERSION: Continua version</span></p><p><b>value</b>: 4.1</p></blockquote><blockquote><p><b>version</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 531974}\">MDC_ID_PROD_SPEC_HW: Hardware version</span></p><p><b>value</b>: 0.00</p></blockquote><blockquote><p><b>version</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 531975}\">MDC_ID_PROD_SPEC_SW: Software version</span></p><p><b>value</b>: 0.00</p></blockquote><blockquote><p><b>version</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 531976}\">MDC_ID_PROD_SPEC_FW: Firmware version</span></p><p><b>value</b>: BLP009_02_005 </p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 532353}\">MDC_REG_CERT_DATA_CONTINUA_CERT_DEV_LIST: Continua certified device list</span></p><p><b>valueCode</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaPHD 32775}\">BluetoothLE: Blood pressure monitor</span></p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 68220}\">MDC_TIME_SYNC_PROTOCOL: Time synchronization protocol</span></p><p><b>valueCode</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 532224}\">MDC_TIME_SYNC_NONE: No time synchronization</span></p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7 532354.0}\">regulation-status</span></p><p><b>valueCode</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 N}\">Device is regulated</span></p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7 68219.0}\">mds-time-capab-real-time-clock</span></p><p><b>valueCode</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Real time clock is supported</span></p></blockquote><blockquote><p><b>property</b></p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7 68219.1}\">mds-time-capab-set-clock</span></p><p><b>valueCode</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Setting the real time clock is supported</span></p></blockquote></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaDeviceIdentifiers",
                  "code" : "SYSID",
                  "display" : "Ieee 11073 System Identifier"
                }
              ]
            },
            "system" : "urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2680",
            "value" : "C4-F3-12-FF-FE-53-F2-C9"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaDeviceIdentifiers",
                  "code" : "BTMAC",
                  "display" : "Bluetooth MAC address"
                }
              ]
            },
            "system" : "http://hl7.org/fhir/sid/eui-48/bluetooth",
            "value" : "C4-F3-12-53-F2-C9"
          }
        ],
        "manufacturer" : "A&D Medical ",
        "serialNumber" : "5181000124",
        "modelNumber" : "UA-651BLE ",
        "type" : {
          "coding" : [
            {
              "system" : "urn:iso:std:iso:11073:10101",
              "code" : "65573",
              "display" : "MDC_MOC_VMS_MDS_SIMP"
            }
          ],
          "text" : "MDC_MOC_VMS_MDS_SIMP: Personal health device"
        },
        "specialization" : [
          {
            "systemType" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "528391",
                  "display" : "MDC_DEV_SPEC_PROFILE_BP"
                }
              ],
              "text" : "MDC_DEV_SPEC_PROFILE_BP: Blood Pressure meter"
            },
            "version" : "1"
          }
        ],
        "version" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "532352",
                  "display" : "MDC_REG_CERT_DATA_CONTINUA_VERSION"
                }
              ],
              "text" : "MDC_REG_CERT_DATA_CONTINUA_VERSION: Continua version"
            },
            "value" : "4.1"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "531974",
                  "display" : "MDC_ID_PROD_SPEC_HW"
                }
              ],
              "text" : "MDC_ID_PROD_SPEC_HW: Hardware version"
            },
            "value" : "0.00"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "531975",
                  "display" : "MDC_ID_PROD_SPEC_SW"
                }
              ],
              "text" : "MDC_ID_PROD_SPEC_SW: Software version"
            },
            "value" : "0.00"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "531976",
                  "display" : "MDC_ID_PROD_SPEC_FW"
                }
              ],
              "text" : "MDC_ID_PROD_SPEC_FW: Firmware version"
            },
            "value" : "BLP009_02_005 "
          }
        ],
        "property" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "532353",
                  "display" : "MDC_REG_CERT_DATA_CONTINUA_CERT_DEV_LIST"
                }
              ],
              "text" : "MDC_REG_CERT_DATA_CONTINUA_CERT_DEV_LIST: Continua certified device list"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaPHD",
                    "code" : "32775"
                  }
                ],
                "text" : "BluetoothLE: Blood pressure monitor"
              }
            ]
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "68220",
                  "display" : "MDC_TIME_SYNC_PROTOCOL"
                }
              ],
              "text" : "MDC_TIME_SYNC_PROTOCOL: Time synchronization protocol"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "urn:iso:std:iso:11073:10101",
                    "code" : "532224",
                    "display" : "MDC_TIME_SYNC_NONE"
                  }
                ],
                "text" : "MDC_TIME_SYNC_NONE: No time synchronization"
              }
            ]
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7",
                  "code" : "532354.0"
                }
              ],
              "text" : "regulation-status"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                    "code" : "N"
                  }
                ],
                "text" : "Device is regulated"
              }
            ]
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7",
                  "code" : "68219.0"
                }
              ],
              "text" : "mds-time-capab-real-time-clock"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                    "code" : "Y"
                  }
                ],
                "text" : "Real time clock is supported"
              }
            ]
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7",
                  "code" : "68219.1"
                }
              ],
              "text" : "mds-time-capab-set-clock"
            },
            "valueCode" : [
              {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                    "code" : "Y"
                  }
                ],
                "text" : "Setting the real time clock is supported"
              }
            ]
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Device",
        "ifNoneExist" : "identifier=urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2680|C4-F3-12-FF-FE-53-F2-C9"
      }
    },
    {
      "fullUrl" : "http://hl7.dk/fhir/core/Observation/BatteryLevel.0944",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "BatteryLevel.0944",
        "meta" : {
          "profile" : [
            "http://hl7.dk/fhir/core/StructureDefinition/dk-core-observation",
            "http://hl7.org/fhir/uv/phd/StructureDefinition/PhdNumericObservation"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_BatteryLevel.0944\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation BatteryLevel.0944</b></p><a name=\"BatteryLevel.0944\"> </a><a name=\"hcBatteryLevel.0944\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-dk-core-observation.html\">Danish Core Observation Profile</a>, <a href=\"http://hl7.org/fhir/uv/phd/STU1.1/StructureDefinition-PhdNumericObservation.html\">PhdNumericObservation</a></p></div><p><b>Observation Gateway Device</b>: <a href=\"Device-Telma.FEEDDADADEADBEEF.html\">Device: identifier = IEEE 11073 System Identifier: FE-ED-DA-DA-DE-AD-BE-EF; manufacturer = Trifork; modelNumber = Telma (Android); type = MDC_MOC_VMS_MDS_AHD</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories phd-observation}\">PHD generated Observation</span></p><p><b>code</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 67996}\">MDC_ATTR_VAL_BATT_CHARGE: Battery level</span></p><p><b>subject</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>effective</b>: 2023-02-23 10:24:34+0100</p><p><b>performer</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>value</b>: 95 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>device</b>: <a href=\"Device-BPMonitor.C4F312FFFE53F2C9.html\">Device: identifier = Ieee 11073 System Identifier: C4-F3-12-FF-FE-53-F2-C9,Bluetooth MAC address: Bluetooth Address as a device identifier#C4-F3-12-53-F2-C9; manufacturer = A&amp;D Medical ; serialNumber = 5181000124; modelNumber = UA-651BLE ; type = MDC_MOC_VMS_MDS_SIMP</a></p></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/observation-gatewayDevice",
            "valueReference" : {
              "reference" : "Device/Telma.FEEDDADADEADBEEF"
            }
          }
        ],
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories",
                "code" : "phd-observation",
                "display" : "PHD generated Observation"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "urn:iso:std:iso:11073:10101",
              "code" : "67996",
              "display" : "MDC_ATTR_VAL_BATT_CHARGE"
            }
          ],
          "text" : "MDC_ATTR_VAL_BATT_CHARGE: Battery level"
        },
        "subject" : {
          "reference" : "Patient/Poul"
        },
        "effectiveDateTime" : "2023-02-23T10:24:34.563+01:00",
        "performer" : [
          {
            "reference" : "Patient/Poul"
          }
        ],
        "valueQuantity" : {
          "value" : 95,
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        },
        "device" : {
          "reference" : "Device/BPMonitor.C4F312FFFE53F2C9"
        }
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation"
      }
    },
    {
      "fullUrl" : "http://hl7.dk/fhir/core/Observation/CoincidentTimeStamp.0222",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "CoincidentTimeStamp.0222",
        "meta" : {
          "profile" : [
            "http://hl7.dk/fhir/core/StructureDefinition/dk-core-observation",
            "http://hl7.org/fhir/uv/phd/StructureDefinition/PhdCoincidentTimeStampObservation"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_CoincidentTimeStamp.0222\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation CoincidentTimeStamp.0222</b></p><a name=\"CoincidentTimeStamp.0222\"> </a><a name=\"hcCoincidentTimeStamp.0222\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-dk-core-observation.html\">Danish Core Observation Profile</a>, <a href=\"http://hl7.org/fhir/uv/phd/STU1.1/StructureDefinition-PhdCoincidentTimeStampObservation.html\">PhdCoincidentTimeStampObservation</a></p></div><p><b>Observation Gateway Device</b>: <a href=\"Device-Telma.FEEDDADADEADBEEF.html\">Device: identifier = IEEE 11073 System Identifier: FE-ED-DA-DA-DE-AD-BE-EF; manufacturer = Trifork; modelNumber = Telma (Android); type = MDC_MOC_VMS_MDS_AHD</a></p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 67975}\">MDC_ATTR_TIME_ABS: Uses Absolute time clock</span></p><p><b>subject</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>effective</b>: 2023-02-23 10:24:34+0100</p><p><b>performer</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>value</b>: 2023-02-23 10:24:25+0100</p><p><b>device</b>: <a href=\"Device-BPMonitor.C4F312FFFE53F2C9.html\">Device: identifier = Ieee 11073 System Identifier: C4-F3-12-FF-FE-53-F2-C9,Bluetooth MAC address: Bluetooth Address as a device identifier#C4-F3-12-53-F2-C9; manufacturer = A&amp;D Medical ; serialNumber = 5181000124; modelNumber = UA-651BLE ; type = MDC_MOC_VMS_MDS_SIMP</a></p></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/observation-gatewayDevice",
            "valueReference" : {
              "reference" : "Device/Telma.FEEDDADADEADBEEF"
            }
          }
        ],
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "urn:iso:std:iso:11073:10101",
              "code" : "67975",
              "display" : "MDC_ATTR_TIME_ABS"
            }
          ],
          "text" : "MDC_ATTR_TIME_ABS: Uses Absolute time clock"
        },
        "subject" : {
          "reference" : "Patient/Poul"
        },
        "effectiveDateTime" : "2023-02-23T10:24:34.467+01:00",
        "performer" : [
          {
            "reference" : "Patient/Poul"
          }
        ],
        "valueDateTime" : "2023-02-23T10:24:25+01:00",
        "device" : {
          "reference" : "Device/BPMonitor.C4F312FFFE53F2C9"
        }
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation"
      }
    },
    {
      "fullUrl" : "http://hl7.dk/fhir/core/Observation/BloodPressure.Poul.643992",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "BloodPressure.Poul.643992",
        "meta" : {
          "profile" : [
            "http://hl7.dk/fhir/core/StructureDefinition/ipa-dk-core-observation",
            "http://hl7.org/fhir/uv/phd/StructureDefinition/PhdCompoundNumericObservation",
            "http://hl7.org/fhir/StructureDefinition/vitalsigns",
            "http://hl7.org/fhir/StructureDefinition/bp"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_BloodPressure.Poul.643992\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation BloodPressure.Poul.643992</b></p><a name=\"BloodPressure.Poul.643992\"> </a><a name=\"hcBloodPressure.Poul.643992\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ipa-dk-core-observation.html\">Danish IPA Core Observation Profile</a>, <a href=\"http://hl7.org/fhir/uv/phd/STU1.1/StructureDefinition-PhdCompoundNumericObservation.html\">PhdCompoundNumericObservation</a>, <a href=\"http://hl7.org/fhir/R4/vitalsigns.html\">Vital Signs Profile</a>, <a href=\"http://hl7.org/fhir/R4/bp.html\">Observation Blood Pressure Profile</a></p></div><p><b>Observation Gateway Device</b>: <a href=\"Device-Telma.FEEDDADADEADBEEF.html\">Device: identifier = IEEE 11073 System Identifier: FE-ED-DA-DA-DE-AD-BE-EF; manufacturer = Trifork; modelNumber = Telma (Android); type = MDC_MOC_VMS_MDS_AHD</a></p><p><b>identifier</b>: C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-150020-118-266016-87-266016-99-266016-20230223T102408.00</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital signs</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories phd-observation}\">PHD generated Observation</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85354-9}, {urn:iso:std:iso:11073:10101 150020}, {urn:oid:1.2.208.176.2.4 ZZ3170}\">MDC_PRESS_BLD_NONINV: Blood Pressure</span></p><p><b>subject</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>effective</b>: 2023-02-23 10:24:08+0100</p><p><b>performer</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>device</b>: <a href=\"Device-BPMonitor.C4F312FFFE53F2C9.html\">Device: identifier = Ieee 11073 System Identifier: C4-F3-12-FF-FE-53-F2-C9,Bluetooth MAC address: Bluetooth Address as a device identifier#C4-F3-12-53-F2-C9; manufacturer = A&amp;D Medical ; serialNumber = 5181000124; modelNumber = UA-651BLE ; type = MDC_MOC_VMS_MDS_SIMP</a></p><p><b>derivedFrom</b>: <a href=\"Observation-CoincidentTimeStamp.0222.html\">Observation MDC_ATTR_TIME_ABS</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8480-6}, {urn:iso:std:iso:11073:10101 150021}, {http://npu-terminology.org DNK05472}\">MDC_PRESS_BLD_NONINV_SYS: Systolic Blood Pressure</span></p><p><b>value</b>: 118 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8462-4}, {urn:iso:std:iso:11073:10101 150022}, {http://npu-terminology.org 05473}\">MDC_PRESS_BLD_NONINV_DIA: Diastolic Blood Pressure</span></p><p><b>value</b>: 87 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 150023}\">MDC_PRESS_BLD_NONINV_MEAN: Mean Blood Pressure</span></p><p><b>value</b>: 99 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/observation-gatewayDevice",
            "valueReference" : {
              "reference" : "Device/Telma.FEEDDADADEADBEEF"
            }
          }
        ],
        "identifier" : [
          {
            "value" : "C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-150020-118-266016-87-266016-99-266016-20230223T102408.00"
          }
        ],
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "vital-signs",
                "display" : "Vital signs"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories",
                "code" : "phd-observation",
                "display" : "PHD generated Observation"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "85354-9",
              "display" : "Blood pressure panel with all children optional"
            },
            {
              "system" : "urn:iso:std:iso:11073:10101",
              "code" : "150020",
              "display" : "MDC_PRESS_BLD_NONINV"
            },
            {
              "system" : "urn:oid:1.2.208.176.2.4",
              "code" : "ZZ3170",
              "display" : "Hjemmeblodtryksmåling udført af patienten"
            }
          ],
          "text" : "MDC_PRESS_BLD_NONINV: Blood Pressure"
        },
        "subject" : {
          "reference" : "Patient/Poul"
        },
        "effectiveDateTime" : "2023-02-23T10:24:08+01:00",
        "performer" : [
          {
            "reference" : "Patient/Poul"
          }
        ],
        "device" : {
          "reference" : "Device/BPMonitor.C4F312FFFE53F2C9"
        },
        "derivedFrom" : [
          {
            "reference" : "Observation/CoincidentTimeStamp.0222"
          }
        ],
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "8480-6",
                  "display" : "Systolic blood pressure"
                },
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "150021",
                  "display" : "MDC_PRESS_BLD_NONINV_SYS"
                },
                {
                  "system" : "http://npu-terminology.org",
                  "code" : "DNK05472",
                  "display" : "Arm—Blodtryk(systolisk); tryk = ? mmHg"
                }
              ],
              "text" : "MDC_PRESS_BLD_NONINV_SYS: Systolic Blood Pressure"
            },
            "valueQuantity" : {
              "value" : 118,
              "unit" : "mmHg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mm[Hg]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "8462-4",
                  "display" : "Diastolic blood pressure"
                },
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "150022",
                  "display" : "MDC_PRESS_BLD_NONINV_DIA"
                },
                {
                  "system" : "http://npu-terminology.org",
                  "code" : "05473",
                  "display" : "Arm—Blodtryk(diastolisk); tryk = ? mmHg"
                }
              ],
              "text" : "MDC_PRESS_BLD_NONINV_DIA: Diastolic Blood Pressure"
            },
            "valueQuantity" : {
              "value" : 87,
              "unit" : "mmHg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mm[Hg]"
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "150023",
                  "display" : "MDC_PRESS_BLD_NONINV_MEAN"
                }
              ],
              "text" : "MDC_PRESS_BLD_NONINV_MEAN: Mean Blood Pressure"
            },
            "valueQuantity" : {
              "value" : 99,
              "unit" : "mmHg",
              "system" : "http://unitsofmeasure.org",
              "code" : "mm[Hg]"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation",
        "ifNoneExist" : "identifier=C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-150020-118-266016-87-266016-99-266016-20230223T102408.00"
      }
    },
    {
      "fullUrl" : "http://hl7.dk/fhir/core/Observation/HeartRate.Poul.1974654",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "HeartRate.Poul.1974654",
        "meta" : {
          "profile" : [
            "http://hl7.dk/fhir/core/StructureDefinition/ipa-dk-core-observation",
            "http://hl7.org/fhir/uv/phd/StructureDefinition/PhdNumericObservation",
            "http://hl7.org/fhir/StructureDefinition/vitalsigns",
            "http://hl7.org/fhir/StructureDefinition/heartrate"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_HeartRate.Poul.1974654\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation HeartRate.Poul.1974654</b></p><a name=\"HeartRate.Poul.1974654\"> </a><a name=\"hcHeartRate.Poul.1974654\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-ipa-dk-core-observation.html\">Danish IPA Core Observation Profile</a>, <a href=\"http://hl7.org/fhir/uv/phd/STU1.1/StructureDefinition-PhdNumericObservation.html\">PhdNumericObservation</a>, <a href=\"http://hl7.org/fhir/R4/vitalsigns.html\">Vital Signs Profile</a>, <a href=\"http://hl7.org/fhir/R4/heartrate.html\">Observation Heart Rate Profile</a></p></div><p><b>Observation Gateway Device</b>: <a href=\"Device-Telma.FEEDDADADEADBEEF.html\">Device: identifier = IEEE 11073 System Identifier: FE-ED-DA-DA-DE-AD-BE-EF; manufacturer = Trifork; modelNumber = Telma (Android); type = MDC_MOC_VMS_MDS_AHD</a></p><p><b>identifier</b>: C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-149546-93-{beat}/min-20230223T102408.00</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital signs</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories phd-observation}\">PHD generated Observation</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8867-4}, {urn:iso:std:iso:11073:10101 149546}, {http://npu-terminology.org NPU21692}\">MDC_PULS_RATE_NON_INV: Heart rate</span></p><p><b>subject</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>effective</b>: 2023-02-23 10:24:08+0100</p><p><b>performer</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>value</b>: 93 bpm<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/min = '/min')</span></p><p><b>device</b>: <a href=\"Device-BPMonitor.C4F312FFFE53F2C9.html\">Device: identifier = Ieee 11073 System Identifier: C4-F3-12-FF-FE-53-F2-C9,Bluetooth MAC address: Bluetooth Address as a device identifier#C4-F3-12-53-F2-C9; manufacturer = A&amp;D Medical ; serialNumber = 5181000124; modelNumber = UA-651BLE ; type = MDC_MOC_VMS_MDS_SIMP</a></p><p><b>derivedFrom</b>: <a href=\"Observation-CoincidentTimeStamp.0222.html\">Observation MDC_ATTR_TIME_ABS</a></p></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/observation-gatewayDevice",
            "valueReference" : {
              "reference" : "Device/Telma.FEEDDADADEADBEEF"
            }
          }
        ],
        "identifier" : [
          {
            "value" : "C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-149546-93-{beat}/min-20230223T102408.00"
          }
        ],
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "vital-signs",
                "display" : "Vital signs"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories",
                "code" : "phd-observation",
                "display" : "PHD generated Observation"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "8867-4",
              "display" : "Heart rate"
            },
            {
              "system" : "urn:iso:std:iso:11073:10101",
              "code" : "149546",
              "display" : "MDC_PULS_RATE_NON_INV"
            },
            {
              "system" : "http://npu-terminology.org",
              "code" : "NPU21692",
              "display" : "Heart—Systole; frequency = ? × 1/min"
            }
          ],
          "text" : "MDC_PULS_RATE_NON_INV: Heart rate"
        },
        "subject" : {
          "reference" : "Patient/Poul"
        },
        "effectiveDateTime" : "2023-02-23T10:24:08+01:00",
        "performer" : [
          {
            "reference" : "Patient/Poul"
          }
        ],
        "valueQuantity" : {
          "value" : 93,
          "unit" : "bpm",
          "system" : "http://unitsofmeasure.org",
          "code" : "/min"
        },
        "device" : {
          "reference" : "Device/BPMonitor.C4F312FFFE53F2C9"
        },
        "derivedFrom" : [
          {
            "reference" : "Observation/CoincidentTimeStamp.0222"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation",
        "ifNoneExist" : "identifier=C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-149546-93-{beat}/min-20230223T102408.00"
      }
    },
    {
      "fullUrl" : "http://hl7.dk/fhir/core/Observation/BloodPressureStatus.Poul.133527",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "BloodPressureStatus.Poul.133527",
        "meta" : {
          "profile" : [
            "http://hl7.dk/fhir/core/StructureDefinition/dk-core-observation",
            "http://hl7.org/fhir/uv/phd/StructureDefinition/PhdBitsEnumerationObservation"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_BloodPressureStatus.Poul.133527\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation BloodPressureStatus.Poul.133527</b></p><a name=\"BloodPressureStatus.Poul.133527\"> </a><a name=\"hcBloodPressureStatus.Poul.133527\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-dk-core-observation.html\">Danish Core Observation Profile</a>, <a href=\"http://hl7.org/fhir/uv/phd/STU1.1/StructureDefinition-PhdBitsEnumerationObservation.html\">PhdBitsEnumerationObservation</a></p></div><p><b>Observation Gateway Device</b>: <a href=\"Device-Telma.FEEDDADADEADBEEF.html\">Device: identifier = IEEE 11073 System Identifier: FE-ED-DA-DA-DE-AD-BE-EF; manufacturer = Trifork; modelNumber = Telma (Android); type = MDC_MOC_VMS_MDS_AHD</a></p><p><b>identifier</b>: C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-8410608-8192-20230223T102408.00</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories phd-observation}\">PHD generated Observation</span></p><p><b>code</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 8410608}\">MDC_BLOOD_PRESSURE_MEASUREMENT_STATUS: Blood Pressure measurement problem</span></p><p><b>subject</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>effective</b>: 2023-02-23 10:24:08+0100</p><p><b>performer</b>: <a href=\"Patient-Poul.html\">Poul Hansen (no stated gender), DoB Unknown ( National unique individual identifier)</a></p><p><b>device</b>: <a href=\"Device-BPMonitor.C4F312FFFE53F2C9.html\">Device: identifier = Ieee 11073 System Identifier: C4-F3-12-FF-FE-53-F2-C9,Bluetooth MAC address: Bluetooth Address as a device identifier#C4-F3-12-53-F2-C9; manufacturer = A&amp;D Medical ; serialNumber = 5181000124; modelNumber = UA-651BLE ; type = MDC_MOC_VMS_MDS_SIMP</a></p><p><b>derivedFrom</b>: </p><ul><li><a href=\"Observation-CoincidentTimeStamp.0222.html\">Observation MDC_ATTR_TIME_ABS</a></li><li><a href=\"Bundle-ContinuaBundleWithDevice.html#Observation_BloodPressure.Poul.643992\">Observation Blood pressure panel with all children optional</a></li></ul><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7 8410608.2}\">irregular-pulse</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Irregular pulse was detected</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/observation-gatewayDevice",
            "valueReference" : {
              "reference" : "Device/Telma.FEEDDADADEADBEEF"
            }
          }
        ],
        "identifier" : [
          {
            "value" : "C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-8410608-8192-20230223T102408.00"
          }
        ],
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories",
                "code" : "phd-observation",
                "display" : "PHD generated Observation"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "urn:iso:std:iso:11073:10101",
              "code" : "8410608",
              "display" : "MDC_BLOOD_PRESSURE_MEASUREMENT_STATUS"
            }
          ],
          "text" : "MDC_BLOOD_PRESSURE_MEASUREMENT_STATUS: Blood Pressure measurement problem"
        },
        "subject" : {
          "reference" : "Patient/Poul"
        },
        "effectiveDateTime" : "2023-02-23T10:24:08+01:00",
        "performer" : [
          {
            "reference" : "Patient/Poul"
          }
        ],
        "device" : {
          "reference" : "Device/BPMonitor.C4F312FFFE53F2C9"
        },
        "derivedFrom" : [
          {
            "reference" : "Observation/CoincidentTimeStamp.0222"
          },
          {
            "reference" : "Observation/BloodPressure.Poul.643992"
          }
        ],
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ASN1ToHL7",
                  "code" : "8410608.2"
                }
              ],
              "text" : "irregular-pulse"
            },
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                  "code" : "Y"
                }
              ],
              "text" : "Irregular pulse was detected"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation",
        "ifNoneExist" : "identifier=C4F312FFFE53F2C9-3001749995-urn:oid:1.2.208.176.1.2-8410608-8192-20230223T102408.00"
      }
    }
  ]
}

```
