# DK Municipality Codes - HL7 FHIR Implementation Guide: DK Core v3.7.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DK Municipality Codes**

## CodeSystem: DK Municipality Codes 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.dk/fhir/core/CodeSystem/dk-core-municipality-codes | *Version*:3.7.0 |
| Active as of 2026-05-30 | *Computable Name*:MunicipalityCodes |

 
Municipality codes as defined by https://danmarksadresser.dk/adressedata/kodelister/kommunekodeliste/ and https://sundhedsdatastyrelsen.dk/-/media/sds/filer/rammer-og-retningslinjer/patientregistrering/relaterede/kommuneklassifikation.pdf 

 This Code system is referenced in the content logical definition of the following value sets: 

* [MunicipalityCodes](ValueSet-dk-core-MunicipalityCodes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "dk-core-municipality-codes",
  "url" : "http://hl7.dk/fhir/core/CodeSystem/dk-core-municipality-codes",
  "version" : "3.7.0",
  "name" : "MunicipalityCodes",
  "title" : "DK Municipality Codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-05-30T15:25:27+02:00",
  "publisher" : "HL7 Denmark",
  "contact" : [{
    "name" : "HL7 Denmark",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.hl7.dk"
    },
    {
      "system" : "email",
      "value" : "dk-affiliate@hl7.dk"
    }]
  }],
  "description" : "Municipality codes as defined by https://danmarksadresser.dk/adressedata/kodelister/kommunekodeliste/ and https://sundhedsdatastyrelsen.dk/-/media/sds/filer/rammer-og-retningslinjer/patientregistrering/relaterede/kommuneklassifikation.pdf",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 99,
  "concept" : [{
    "code" : "0740",
    "display" : "Silkeborg",
    "designation" : [{
      "language" : "da",
      "value" : "Silkeborg"
    }]
  },
  {
    "code" : "0741",
    "display" : "Samsø",
    "designation" : [{
      "language" : "da",
      "value" : "Samsø"
    }]
  },
  {
    "code" : "0851",
    "display" : "Aalborg",
    "designation" : [{
      "language" : "da",
      "value" : "Aalborg"
    }]
  },
  {
    "code" : "0746",
    "display" : "Skanderborg",
    "designation" : [{
      "language" : "da",
      "value" : "Skanderborg"
    }]
  },
  {
    "code" : "0151",
    "display" : "Ballerup",
    "designation" : [{
      "language" : "da",
      "value" : "Ballerup"
    }]
  },
  {
    "code" : "0260",
    "display" : "Halsnæs",
    "designation" : [{
      "language" : "da",
      "value" : "Halsnæs"
    }]
  },
  {
    "code" : "0153",
    "display" : "Brøndby",
    "designation" : [{
      "language" : "da",
      "value" : "Brøndby"
    }]
  },
  {
    "code" : "0370",
    "display" : "Næstved",
    "designation" : [{
      "language" : "da",
      "value" : "Næstved"
    }]
  },
  {
    "code" : "0155",
    "display" : "Dragør",
    "designation" : [{
      "language" : "da",
      "value" : "Dragør"
    }]
  },
  {
    "code" : "0480",
    "display" : "Nordfyns",
    "designation" : [{
      "language" : "da",
      "value" : "Nordfyns"
    }]
  },
  {
    "code" : "0157",
    "display" : "Gentofte",
    "designation" : [{
      "language" : "da",
      "value" : "Gentofte"
    }]
  },
  {
    "code" : "0265",
    "display" : "Roskilde",
    "designation" : [{
      "language" : "da",
      "value" : "Roskilde"
    }]
  },
  {
    "code" : "0159",
    "display" : "Gladsaxe",
    "designation" : [{
      "language" : "da",
      "value" : "Gladsaxe"
    }]
  },
  {
    "code" : "0376",
    "display" : "Guldborgsund",
    "designation" : [{
      "language" : "da",
      "value" : "Guldborgsund"
    }]
  },
  {
    "code" : "0269",
    "display" : "Solrød",
    "designation" : [{
      "language" : "da",
      "value" : "Solrød"
    }]
  },
  {
    "code" : "0482",
    "display" : "Langeland",
    "designation" : [{
      "language" : "da",
      "value" : "Langeland"
    }]
  },
  {
    "code" : "0201",
    "display" : "Allerød",
    "designation" : [{
      "language" : "da",
      "value" : "Allerød"
    }]
  },
  {
    "code" : "0420",
    "display" : "Assens",
    "designation" : [{
      "language" : "da",
      "value" : "Assens"
    }]
  },
  {
    "code" : "0530",
    "display" : "Billund",
    "designation" : [{
      "language" : "da",
      "value" : "Billund"
    }]
  },
  {
    "code" : "0316",
    "display" : "Holbæk",
    "designation" : [{
      "language" : "da",
      "value" : "Holbæk"
    }]
  },
  {
    "code" : "0751",
    "display" : "Aarhus",
    "designation" : [{
      "language" : "da",
      "value" : "Aarhus"
    }]
  },
  {
    "code" : "0860",
    "display" : "Hjørring",
    "designation" : [{
      "language" : "da",
      "value" : "Hjørring"
    }]
  },
  {
    "code" : "0756",
    "display" : "Ikast-Brande",
    "designation" : [{
      "language" : "da",
      "value" : "Ikast-Brande"
    }]
  },
  {
    "code" : "0161",
    "display" : "Glostrup",
    "designation" : [{
      "language" : "da",
      "value" : "Glostrup"
    }]
  },
  {
    "code" : "0270",
    "display" : "Gribskov",
    "designation" : [{
      "language" : "da",
      "value" : "Gribskov"
    }]
  },
  {
    "code" : "0163",
    "display" : "Herlev",
    "designation" : [{
      "language" : "da",
      "value" : "Herlev"
    }]
  },
  {
    "code" : "0165",
    "display" : "Albertslund",
    "designation" : [{
      "language" : "da",
      "value" : "Albertslund"
    }]
  },
  {
    "code" : "0167",
    "display" : "Hvidovre",
    "designation" : [{
      "language" : "da",
      "value" : "Hvidovre"
    }]
  },
  {
    "code" : "0492",
    "display" : "Ærø",
    "designation" : [{
      "language" : "da",
      "value" : "Ærø"
    }]
  },
  {
    "code" : "0169",
    "display" : "Høje-Taastrup",
    "designation" : [{
      "language" : "da",
      "value" : "Høje-Taastrup"
    }]
  },
  {
    "code" : "0101",
    "display" : "København",
    "designation" : [{
      "language" : "da",
      "value" : "København"
    }]
  },
  {
    "code" : "0210",
    "display" : "Fredensborg",
    "designation" : [{
      "language" : "da",
      "value" : "Fredensborg"
    }]
  },
  {
    "code" : "0320",
    "display" : "Faxe",
    "designation" : [{
      "language" : "da",
      "value" : "Faxe"
    }]
  },
  {
    "code" : "0430",
    "display" : "Faaborg-Midtfyn",
    "designation" : [{
      "language" : "da",
      "value" : "Faaborg-Midtfyn"
    }]
  },
  {
    "code" : "0540",
    "display" : "Sønderborg",
    "designation" : [{
      "language" : "da",
      "value" : "Sønderborg"
    }]
  },
  {
    "code" : "0217",
    "display" : "Helsingør",
    "designation" : [{
      "language" : "da",
      "value" : "Helsingør"
    }]
  },
  {
    "code" : "0326",
    "display" : "Kalundborg",
    "designation" : [{
      "language" : "da",
      "value" : "Kalundborg"
    }]
  },
  {
    "code" : "0219",
    "display" : "Hillerød",
    "designation" : [{
      "language" : "da",
      "value" : "Hillerød"
    }]
  },
  {
    "code" : "0760",
    "display" : "Ringkøbing-Skjern",
    "designation" : [{
      "language" : "da",
      "value" : "Ringkøbing-Skjern"
    }]
  },
  {
    "code" : "0329",
    "display" : "Ringsted",
    "designation" : [{
      "language" : "da",
      "value" : "Ringsted"
    }]
  },
  {
    "code" : "0657",
    "display" : "Herning",
    "designation" : [{
      "language" : "da",
      "value" : "Herning"
    }]
  },
  {
    "code" : "0766",
    "display" : "Hedensted",
    "designation" : [{
      "language" : "da",
      "value" : "Hedensted"
    }]
  },
  {
    "code" : "0173",
    "display" : "Lyngby-Taarbæk",
    "designation" : [{
      "language" : "da",
      "value" : "Lyngby-Taarbæk"
    }]
  },
  {
    "code" : "0390",
    "display" : "Vordingborg",
    "designation" : [{
      "language" : "da",
      "value" : "Vordingborg"
    }]
  },
  {
    "code" : "0175",
    "display" : "Rødovre",
    "designation" : [{
      "language" : "da",
      "value" : "Rødovre"
    }]
  },
  {
    "code" : "0810",
    "display" : "Brønderslev",
    "designation" : [{
      "language" : "da",
      "value" : "Brønderslev"
    }]
  },
  {
    "code" : "0813",
    "display" : "Frederikshavn",
    "designation" : [{
      "language" : "da",
      "value" : "Frederikshavn"
    }]
  },
  {
    "code" : "0706",
    "display" : "Syddjurs",
    "designation" : [{
      "language" : "da",
      "value" : "Syddjurs"
    }]
  },
  {
    "code" : "0707",
    "display" : "Norddjurs",
    "designation" : [{
      "language" : "da",
      "value" : "Norddjurs"
    }]
  },
  {
    "code" : "0330",
    "display" : "Slagelse",
    "designation" : [{
      "language" : "da",
      "value" : "Slagelse"
    }]
  },
  {
    "code" : "0223",
    "display" : "Hørsholm",
    "designation" : [{
      "language" : "da",
      "value" : "Hørsholm"
    }]
  },
  {
    "code" : "0440",
    "display" : "Kerteminde",
    "designation" : [{
      "language" : "da",
      "value" : "Kerteminde"
    }]
  },
  {
    "code" : "0550",
    "display" : "Tønder",
    "designation" : [{
      "language" : "da",
      "value" : "Tønder"
    }]
  },
  {
    "code" : "0336",
    "display" : "Stevns",
    "designation" : [{
      "language" : "da",
      "value" : "Stevns"
    }]
  },
  {
    "code" : "0661",
    "display" : "Holstebro",
    "designation" : [{
      "language" : "da",
      "value" : "Holstebro"
    }]
  },
  {
    "code" : "0665",
    "display" : "Lemvig",
    "designation" : [{
      "language" : "da",
      "value" : "Lemvig"
    }]
  },
  {
    "code" : "0773",
    "display" : "Morsø",
    "designation" : [{
      "language" : "da",
      "value" : "Morsø"
    }]
  },
  {
    "code" : "0779",
    "display" : "Skive",
    "designation" : [{
      "language" : "da",
      "value" : "Skive"
    }]
  },
  {
    "code" : "0183",
    "display" : "Ishøj",
    "designation" : [{
      "language" : "da",
      "value" : "Ishøj"
    }]
  },
  {
    "code" : "0185",
    "display" : "Tårnby",
    "designation" : [{
      "language" : "da",
      "value" : "Tårnby"
    }]
  },
  {
    "code" : "0710",
    "display" : "Favrskov",
    "designation" : [{
      "language" : "da",
      "value" : "Favrskov"
    }]
  },
  {
    "code" : "0187",
    "display" : "Vallensbæk",
    "designation" : [{
      "language" : "da",
      "value" : "Vallensbæk"
    }]
  },
  {
    "code" : "0820",
    "display" : "Vesthimmerland",
    "designation" : [{
      "language" : "da",
      "value" : "Vesthimmerland"
    }]
  },
  {
    "code" : "0607",
    "display" : "Fredericia",
    "designation" : [{
      "language" : "da",
      "value" : "Fredericia"
    }]
  },
  {
    "code" : "0825",
    "display" : "Læsø",
    "designation" : [{
      "language" : "da",
      "value" : "Læsø"
    }]
  },
  {
    "code" : "0230",
    "display" : "Rudersdal",
    "designation" : [{
      "language" : "da",
      "value" : "Rudersdal"
    }]
  },
  {
    "code" : "0340",
    "display" : "Sorø",
    "designation" : [{
      "language" : "da",
      "value" : "Sorø"
    }]
  },
  {
    "code" : "0450",
    "display" : "Nyborg",
    "designation" : [{
      "language" : "da",
      "value" : "Nyborg"
    }]
  },
  {
    "code" : "0561",
    "display" : "Esbjerg",
    "designation" : [{
      "language" : "da",
      "value" : "Esbjerg"
    }]
  },
  {
    "code" : "0563",
    "display" : "Fanø",
    "designation" : [{
      "language" : "da",
      "value" : "Fanø"
    }]
  },
  {
    "code" : "0671",
    "display" : "Struer",
    "designation" : [{
      "language" : "da",
      "value" : "Struer"
    }]
  },
  {
    "code" : "0190",
    "display" : "Furesø",
    "designation" : [{
      "language" : "da",
      "value" : "Furesø"
    }]
  },
  {
    "code" : "0787",
    "display" : "Thisted",
    "designation" : [{
      "language" : "da",
      "value" : "Thisted"
    }]
  },
  {
    "code" : "0615",
    "display" : "Horsens",
    "designation" : [{
      "language" : "da",
      "value" : "Horsens"
    }]
  },
  {
    "code" : "0727",
    "display" : "Odder",
    "designation" : [{
      "language" : "da",
      "value" : "Odder"
    }]
  },
  {
    "code" : "0240",
    "display" : "Egedal",
    "designation" : [{
      "language" : "da",
      "value" : "Egedal"
    }]
  },
  {
    "code" : "0350",
    "display" : "Lejre",
    "designation" : [{
      "language" : "da",
      "value" : "Lejre"
    }]
  },
  {
    "code" : "0461",
    "display" : "Odense",
    "designation" : [{
      "language" : "da",
      "value" : "Odense"
    }]
  },
  {
    "code" : "0573",
    "display" : "Varde",
    "designation" : [{
      "language" : "da",
      "value" : "Varde"
    }]
  },
  {
    "code" : "0575",
    "display" : "Vejen",
    "designation" : [{
      "language" : "da",
      "value" : "Vejen"
    }]
  },
  {
    "code" : "0791",
    "display" : "Viborg",
    "designation" : [{
      "language" : "da",
      "value" : "Viborg"
    }]
  },
  {
    "code" : "0400",
    "display" : "Bornholm",
    "designation" : [{
      "language" : "da",
      "value" : "Bornholm"
    }]
  },
  {
    "code" : "0510",
    "display" : "Haderslev",
    "designation" : [{
      "language" : "da",
      "value" : "Haderslev"
    }]
  },
  {
    "code" : "0621",
    "display" : "Kolding",
    "designation" : [{
      "language" : "da",
      "value" : "Kolding"
    }]
  },
  {
    "code" : "0730",
    "display" : "Randers",
    "designation" : [{
      "language" : "da",
      "value" : "Randers"
    }]
  },
  {
    "code" : "0840",
    "display" : "Rebild",
    "designation" : [{
      "language" : "da",
      "value" : "Rebild"
    }]
  },
  {
    "code" : "0846",
    "display" : "Mariagerfjord",
    "designation" : [{
      "language" : "da",
      "value" : "Mariagerfjord"
    }]
  },
  {
    "code" : "0250",
    "display" : "Frederikssund",
    "designation" : [{
      "language" : "da",
      "value" : "Frederikssund"
    }]
  },
  {
    "code" : "0360",
    "display" : "Lolland",
    "designation" : [{
      "language" : "da",
      "value" : "Lolland"
    }]
  },
  {
    "code" : "0253",
    "display" : "Greve",
    "designation" : [{
      "language" : "da",
      "value" : "Greve"
    }]
  },
  {
    "code" : "0849",
    "display" : "Jammerbugt",
    "designation" : [{
      "language" : "da",
      "value" : "Jammerbugt"
    }]
  },
  {
    "code" : "0147",
    "display" : "Frederiksberg",
    "designation" : [{
      "language" : "da",
      "value" : "Frederiksberg"
    }]
  },
  {
    "code" : "0580",
    "display" : "Aabenraa",
    "designation" : [{
      "language" : "da",
      "value" : "Aabenraa"
    }]
  },
  {
    "code" : "0259",
    "display" : "Køge",
    "designation" : [{
      "language" : "da",
      "value" : "Køge"
    }]
  },
  {
    "code" : "0479",
    "display" : "Svendborg",
    "designation" : [{
      "language" : "da",
      "value" : "Svendborg"
    }]
  },
  {
    "code" : "0410",
    "display" : "Middelfart",
    "designation" : [{
      "language" : "da",
      "value" : "Middelfart"
    }]
  },
  {
    "code" : "0411",
    "display" : "Christiansø",
    "designation" : [{
      "language" : "da",
      "value" : "Christiansø"
    }]
  },
  {
    "code" : "0306",
    "display" : "Odsherred",
    "designation" : [{
      "language" : "da",
      "value" : "Odsherred"
    }]
  },
  {
    "code" : "0630",
    "display" : "Vejle",
    "designation" : [{
      "language" : "da",
      "value" : "Vejle"
    }]
  }]
}

```
