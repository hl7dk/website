# DK Related Person Relationship Types - HL7 FHIR Implementation Guide: DK Core v3.7.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DK Related Person Relationship Types**

## ValueSet: DK Related Person Relationship Types 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.dk/fhir/core/ValueSet/dk-core-RelatedPersonRelationshipTypes | *Version*:3.7.0 |
| Active as of 2026-05-30 | *Computable Name*:RelatedPersonRelationshipTypes |

 
DK Related Person Relationship Types 

 **References** 

* Included into [ExtendedPatientContactRelationship](ValueSet-extended-patient-contactrelationship.md)
* [Danish Core Related Person Profile](StructureDefinition-dk-core-related-person.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "dk-core-RelatedPersonRelationshipTypes",
  "url" : "http://hl7.dk/fhir/core/ValueSet/dk-core-RelatedPersonRelationshipTypes",
  "version" : "3.7.0",
  "name" : "RelatedPersonRelationshipTypes",
  "title" : "DK Related Person Relationship Types",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-05-30T15:15:22+02:00",
  "publisher" : "HL7 Denmark",
  "contact" : [{
    "name" : "HL7 Denmark",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.hl7.dk"
    },
    {
      "system" : "email",
      "value" : "dk-affiliate@hl7.dk"
    }]
  }],
  "description" : "DK Related Person Relationship Types",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DK",
      "display" : "Denmark"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
      "version" : "2018-08-12",
      "concept" : [{
        "code" : "FAMMEMB"
      },
      {
        "code" : "CHILD"
      },
      {
        "code" : "DAUC"
      },
      {
        "code" : "SONC"
      },
      {
        "code" : "GRNDCHILD"
      },
      {
        "code" : "GRPRN"
      },
      {
        "code" : "CHLDINLAW"
      },
      {
        "code" : "PRN"
      },
      {
        "code" : "FTH"
      },
      {
        "code" : "MTH"
      },
      {
        "code" : "SIB"
      },
      {
        "code" : "DOMPART"
      },
      {
        "code" : "SPS"
      },
      {
        "code" : "FRND"
      },
      {
        "code" : "NBOR"
      },
      {
        "code" : "ROOM"
      },
      {
        "code" : "GUARD"
      },
      {
        "code" : "NOK"
      },
      {
        "code" : "POWATT"
      },
      {
        "code" : "ECON"
      }]
    },
    {
      "system" : "http://hl7.dk/fhir/core/CodeSystem/dk-relatedperson-relationshipcodes"
    }]
  }
}

```
