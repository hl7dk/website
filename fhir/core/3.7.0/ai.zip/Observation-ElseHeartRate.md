# ElseHeartRate - HL7 FHIR Implementation Guide: DK Core v3.7.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ElseHeartRate**

## Example Observation: ElseHeartRate

Profile: [Danish Core Basic Observation Profile](StructureDefinition-dk-core-basic-observation.md)

**status**: Final

**category**: Vital Signs

**code**: Heart rate

**subject**: [Else Test Lauridsen(official) Female, DoB: 1991-02-02 ( urn:oid:1.2.208.176.1.2#DK Central Person Registry (CPR)#0201919990)](Patient-else.md)

**effective**: 2023-09-12 17:45:00+0000

**performer**: [Practitioner Sidsel Andersen](Practitioner-SidselSygeplejerske.md)

**value**: 92 slag/minut (Details: UCUM code/min = '/min')

**method**: måling



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ElseHeartRate",
  "meta" : {
    "profile" : ["http://hl7.dk/fhir/core/StructureDefinition/dk-core-basic-observation"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "8867-4"
    },
    {
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/554471000005108",
      "code" : "364075005"
    }]
  },
  "subject" : {
    "reference" : "Patient/else"
  },
  "effectiveDateTime" : "2023-09-12T17:45:00.000Z",
  "performer" : [{
    "reference" : "Practitioner/SidselSygeplejerske"
  }],
  "valueQuantity" : {
    "value" : 92,
    "unit" : "slag/minut",
    "system" : "http://unitsofmeasure.org",
    "code" : "/min"
  },
  "method" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/554471000005108",
      "code" : "272391002",
      "display" : "måling"
    }]
  }
}

```
